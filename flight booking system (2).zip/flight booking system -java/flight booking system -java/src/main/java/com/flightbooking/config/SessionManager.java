package com.flightbooking.config;

import org.springframework.stereotype.Component;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class SessionManager {

    private final ConcurrentHashMap<String, Integer> sessions = new ConcurrentHashMap<>();

    public String createSession(int userId) {
        String token = UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
        sessions.put(token, userId);
        return token;
    }

    public Integer getUserId(String token) {
        if (token == null) return null;
        return sessions.get(token);
    }

    public void invalidate(String token) {
        if (token != null) {
            sessions.remove(token);
        }
    }

    public Integer extractUserId(String authHeader) {
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return getUserId(authHeader.substring(7));
        }
        return null;
    }
}
