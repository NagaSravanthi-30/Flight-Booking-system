package com.flightbooking.dao;

import com.flightbooking.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;

@Repository
public class UserDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private final RowMapper<User> userMapper = (rs, rowNum) -> {
        User u = new User();
        u.setUserId(rs.getInt("user_id"));
        u.setName(rs.getString("name"));
        u.setEmail(rs.getString("email"));
        u.setPassword(rs.getString("password"));
        u.setRole(rs.getString("role"));
        return u;
    };

    public User register(String name, String email, String password) {
        try {
            findByEmail(email);
            return null;
        } catch (EmptyResultDataAccessException ignored) {}

        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'PASSENGER')",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            return ps;
        }, keyHolder);

        int userId = keyHolder.getKey().intValue();
        User user = new User();
        user.setUserId(userId);
        user.setName(name);
        user.setEmail(email);
        user.setRole("PASSENGER");
        return user;
    }

    public User login(String email, String password) {
        try {
            User user = findByEmail(email);
            if (user.getPassword().equals(password)) {
                return user;
            }
            return null;
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    public User findByEmail(String email) {
        return jdbcTemplate.queryForObject(
                "SELECT * FROM users WHERE email = ?", userMapper, email);
    }

    public User findById(int userId) {
        try {
            return jdbcTemplate.queryForObject(
                    "SELECT * FROM users WHERE user_id = ?", userMapper, userId);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }
}
